module.exports = {
  token: {
    Primary:
      "",
    Secondary:
      "OTM3Mjc5ODYzNjUwNDA2NDQw.G7a_8k.tg-g0RXOE7qoKIZlJpCoZMknBG_l5UlN0kmwrE",
  },
  tokenTopgg: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjkwNDMxNzE0MTg2NjY0NzU5MiIsImJvdCI6dHJ1ZSwiaWF0IjoxNjczNTI3OTYzfQ.WwA0KXh_nAQcBmR7BPqgLGyElYZheTQmguQfA2F6aNc",
  mongoURL: {
    Primary: "mongodb+srv://xtezz2:tejas49@sia.6srhf.mongodb.net/test",
    Secondary: "mongodb+srv://xtezz2:tejas49@sia.6srhf.mongodb.net/test",
  },
  clusterMode: "DEVELOPMENT",
  def_prefix: "+",
  vote_bypass: ["900981299022536757", "785708354445508649"],
  vote:`https://top.gg/bot/904317141866647592/vote`,
  developers: ["900981299022536757", "785708354445508649"],
  managers: ["abc", "def"],
  support: "https://discord.gg/coderz",
  invite: "https://discord.com/oauth2/authorize?client_id=904317141866647592&permissions=8&scope=bot%20applications.commands",
  color: "#2f3136",
  webhook: {
    guildAdd: `https://discord.com/api/webhooks/1246792443261747271/mYXEIHpuiw7hs9X5mA8mI5AfdBAxBx3jZjC5Vmjx1ShKxdDbkp1P7-hWwQ4RdEwYzk10`,
    guildRemove: `https://discord.com/api/webhooks/1246792519178653787/m2J7sEcjQ3KnH2o-zJYc_PT527JGAmBWytK_NSxxhQML0mDaAFtv2VWlF2bDtCsCwkBa`,
    commandRun: `https://discord.com/api/webhooks/1246751004867952702/ozZdbIwANHOK6UOVKCm2L5IpIR75MRPozT6nCFdYGp6xrKAtuhcd8toUlMaWB7mrqZ3Q`,
  },
  LOGGINGS: {
    guildAdd:
      "https://discord.com/api/webhooks/1246792443261747271/mYXEIHpuiw7h",
    guildRemove:
      "https://discord.com/api/webhooks/1246792519178653787/m2J7sEcjQ3KnH2o-zJYc_PT527JGAmBWytK_",
    commandRun:
      "https://discord.com/api/webhooks/1246751004867952702/ozZdb",
  },
  nodes: [
    {
      name: `Avon`,
      url: `lavalink.jirayu.net:13592`,
      auth: `youshallnotpass`,
      secure: false,
    },
    // {
    //   name: "Sia Main",
    //   url: "0.0.0.0:2333",
    //   auth: "siacanary",
    //   secure: false,
    // },
  ],
};
